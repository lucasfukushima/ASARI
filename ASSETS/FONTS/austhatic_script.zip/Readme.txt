This font for personal use only! You can make unlimited personal project from this font.
----------------------------------------------------
Any donatiaons are very apreciate, PayPal: fandiofficial@icloud.com
----------------------------------------------------
If you want to use this font for commercial use purpose, you can buy and download the commercial license here:
https://www.creativefabrica.com/product/austhatic-script/ref/236571/
----------------------------------------------------
If you have any question about another licenses, dont hesitate to send a mail to me: fandiofficial@icloud.com
----------------------------------------------------
Thanks.
Best Regards,
@halofandi